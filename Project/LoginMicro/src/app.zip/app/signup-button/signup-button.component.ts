import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup-button',
  templateUrl: './signup-button.component.html',
  styleUrls: ['./signup-button.component.css']
})
export class SignupButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

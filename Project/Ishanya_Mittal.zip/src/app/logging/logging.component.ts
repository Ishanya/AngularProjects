import { Component, OnInit } from '@angular/core';
import { LoggedService } from '../logged.service';
import * as encrypt from'crypto-js/sha256';
import {Router,ActivatedRoute,ParamMap} from '@angular/router';
import * as ency from 'crypto-js';
@Component({
  selector: 'app-logging',
  templateUrl: './logging.component.html',
  styleUrls: ['./logging.component.css']
})
export class LoggingComponent implements OnInit {
  
  lename:string;
  lepass:string;
  
  constructor(public _loggedservice:LoggedService,public route:Router) { }

  ngOnInit() {
  }


  login(fname,psswd)
  {
   // alert("hello");
  // alert(fname);
   this._loggedservice.loginn(ency.AES.encrypt(fname,"ABCD").toString(),encrypt(psswd).toString());
   
   /*this.lename="";
   
   this.lepass="";*/
  
  }

  enterSignup()
  {
    this.route.navigate(["/"]);
  }
 
}

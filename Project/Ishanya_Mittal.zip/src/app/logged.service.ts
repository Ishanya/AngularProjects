import { Injectable } from '@angular/core';
import{User} from './user';
import {Router,ActivatedRoute,ParamMap, Route} from '@angular/router';
//var encrypt=require("crypto-js");
import * as encrypt from'crypto-js';
@Injectable({
  providedIn: 'root'
})
export class LoggedService {
logged:User[];
regdUser:User[];
loggin:User[];



  constructor(private route:Router) {
    this.loggin = [
      new User("Ishanya","qwerty"),
];
//localStorage.setItem("regdUser",JSON.stringify(this.loggin));
//this.loggin = JSON.parse(localStorage.getItem("regdUser"));

   }


  loginn(ename,pass)
  {
   // alert(pass);
    //alert(ename);
    var cypertext=encrypt.AES.decrypt(ename,"ABCD");
   var plaintext=cypertext.toString(encrypt.enc.Utf8);
    this.logged=JSON.parse(localStorage.getItem("regdUser"));
     //alert(this.logged.length);
     let flag = 0;
    for(var i=0;i<this.logged.length;i++)
    {

        if(this.logged[i].fname.localeCompare(plaintext)==0 && this.logged[i].password.localeCompare(pass)==0)
        {
         // ename="";
          pass="";
          flag = 1;
         break;
         
        }

    }
    if(flag!=1){
        alert("Username or password is incorrect");
        this.route.navigate(["/login"]);
       
    }
    else{
      this.route.navigate(["/mail",plaintext.toUpperCase()]);
    }
    
  }

  signUp(ename:string,epass:string,ecnfpass:string)
  {
   // alert(epass+" "+ecnfpass);
    //this.loggin.push(new User("Ishanya","qwerty"));
    var cypertext=encrypt.AES.decrypt(ename,"ABCD");
   var plaintext=cypertext.toString(encrypt.enc.Utf8);
   if(epass.localeCompare(ecnfpass)!=0)
   {
    
    alert("Password doesnot match.Try Again!");
    
   
   } 
   else{

     this.loggin=JSON.parse(localStorage.getItem("regdUser"));
     //alert(this.loggin.length);
      this.loggin.push(new User(plaintext,epass));
     //alert(this.loggin.length);
      localStorage.setItem("regdUser",JSON.stringify(this.loggin));
     
      
    // submitted=false;
      alert("You have successfully signedUp");
      this.route.navigate(["/login"]);

   }
  
  }
 

}

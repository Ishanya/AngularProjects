import { Component } from '@angular/core';
import { User } from "./user";
import { LoggedService } from './logged.service';
import {Router,ActivatedRoute,ParamMap} from '@angular/router';
import * as ency from 'crypto-js';
//var ency = require("crypto-js");
import * as encrypt from 'crypto-js/sha256';
//var encrypt=require("crypto-js/sha256");


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  ename:string;
  epass:string;
  ecnfpass:string;
  submitted:boolean;
  togle=true;
  
 
constructor(public _loggedservice:LoggedService,private route:Router){
 
}
 

 signup(fname,pswd,cnfpswd)
 {
   
   this._loggedservice.signUp(ency.AES.encrypt(fname,"ABCD").toString(),encrypt(pswd).toString(),encrypt(cnfpswd).toString());
  
 }
 
 enterLogin()
 {
  
  this.route.navigate(["/login"]);
 }

 
}

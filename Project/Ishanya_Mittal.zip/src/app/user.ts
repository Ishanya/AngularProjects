export class User {
    fname:string;
    password:string;

    constructor(ename:string,epass:string)
    {
        this.fname=ename;
        this.password=epass;
    }
}

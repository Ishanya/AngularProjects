import { Component, OnInit } from '@angular/core';
import { LoggedService } from '../logged.service';
import {Router,ActivatedRoute,ParamMap} from '@angular/router';
@Component({
  selector: 'app-mail',
  templateUrl: './mail.component.html',
  styleUrls: ['./mail.component.css']
})
export class MailComponent implements OnInit {
filledname:string;
filledemail:string;
filledmessage:string;

  constructor(private router:Router, private route:ActivatedRoute) { }

  ngOnInit() {  
     /* let filledname=this.route.snapshot.paramMap.get("ename");
      return filledname;*/
      this.route.paramMap.subscribe((params:ParamMap)=>{
        let filled=params.get('ename');
       this.filledname=filled;
      });

   
    }
    
    logout()
    {
      this.router.navigate(["/"]);
    }

    sendEmail(email:string,message:string)
    {
      if(message.length!=0){
        document.getElementById("msg").innerHTML="";
        alert("we will reply you on "+ "\n" +"email: "+email+ "\n"+"for the message: "+message);
        
    }
        else{
          document.getElementById("msg").innerHTML="message is required";

        }
    }
    
  }



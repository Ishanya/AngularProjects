import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-model',
  templateUrl: './search-model.component.html',
  styleUrls: ['./search-model.component.css']
})
export class SearchModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

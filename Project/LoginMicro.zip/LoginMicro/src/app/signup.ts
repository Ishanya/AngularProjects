export class Signup {
    email:String;
    password:String;
    gender:String;
    postalCode:String;
    city:String;
    state:String;


    constructor( email:String,Password:String,Gender:String,PostalCode:String,City:String,State:String){
        this.email=email;
        this.password=Password;
        this.gender=Gender;
        this.postalCode=PostalCode;
        this.city=City;
        this.state=State;
    }

   
}
export class MovieTest {

    Title: string;
    Year: string;
    Poster: string;
    Actors: string[];
    Director: string[];
    Plot: string;
}

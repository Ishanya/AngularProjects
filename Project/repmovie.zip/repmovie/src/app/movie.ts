export class Movie {
    movieId: string;
    movieName: string;
    moviePosterUrl: string;
    movieReleaseDate: string;
    movieDescription: string;
}
